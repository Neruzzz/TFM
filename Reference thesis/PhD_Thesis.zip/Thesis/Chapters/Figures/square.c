#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <omp.h>

#ifndef DIM
# define DIM 1024
#endif

#ifndef N
# define N 16
#endif

#define BS (DIM/N)
// #ifndef BS
// # define BS 8
// #endif

unsigned long int square[N][N][BS][BS];
#define SIZE (sizeof(square)/sizeof(long long))

#ifdef GOMP_TRACES
extern void GOMP_print_task_counters(void);
#endif

void 
init_matrix()
{
	int i, j, x, y;
	for (i = 0; i < N; ++i) {
		for (j = 0; j < N; ++j) {
			for (x = 0; x < BS; x++) {
				for (y = 0; y < BS; y++) {
					square[i][j][x][y] = 2;					
				}
			}
		}
	}
}

void
sequential(int i, int j)
{
	int x, y;
	
	/*
	 * Leftmost upper item. All the neighbors are in different blocks
	 */
	if (i > 0 && j > 0) {                                  // _________
		square[i][j][0][0] +=                          // | | # | |
		    square[i][j - 1][0][BS - 1] +              // ----#----
		    square[i - 1][j][BS - 1][0]	+              // | |3#2| |
		    square[i - 1][j - 1][BS - 1][BS - 1];      // ____#____
	}	                                               // | |1#o| |
		                                               // ----#----
		                                               // | | # | |
		                                               // ____#____
	/* 
	 * First column of items. Left neighbors are in the left block
	 */
	if (j > 0) {                                           // _________ 
		for (y = 1; y < BS; y++) {                     // | | # | | 
			square[i][j][y][0] +=                  // ----#-----
			    square[i][j - 1][y][BS - 1] +      // | | # | | 
			    square[i][j][y - 1][0] +           // ____#____
			    square[i][j - 1][y - 1][BS - 1];   // | |3#2| | 
		}	                                       // ----#----
	}		                                       // | |1#o| | 
			                                       // ____#____
	/*
	 * First row of items. Upper neighbors are in the upper block
	 */
	if (i > 0) {
		for (x = 1; x < BS; x++) {                     // _________
			square[i][j][0][x] +=                  // | | # | | 
			    square[i][j][0][x - 1] +           // ----#----
			    square[i - 1][j][BS - 1][x] +      // | | #3|2|
			    square[i - 1][j][BS - 1][x - 1];   // ____#____
		}	                                       // | | #1|o|
	}		                                       // ----#----
			                                       // | | # | |
			                                       // ____#_____
	/*
	 * Remaining items. All the neighbors are in the same block
	 */
	for (x = 1; x < BS; x++) {                             // _________
		for (y = 1; y < BS; y++) {                     // |3|1# | | 
			square[i][j][y][x] +=                  // ----#----
			    square[i][j][y][x - 1] +           // |2|o# | |
			    square[i][j][y - 1][x] +           // ____#____
			    square[i][j][y - 1][x - 1];        // | | # | |
		}	                                       // ----#----
	}		                                       // | | # | |

}

long
wavefront(void)
{
//    #pragma omp parallel num_threads (8)
//    #pragma omp master
//    {
    int i, j;

    for (i = 0; i < N; ++i) {
        for (j = 0; j < N; ++j) {
            if (j == 0 && i == 0) {
		#pragma omp task                  \
			depend(inout:square[i][j]) 
		{
                 sequential(i, j);
		}
           } else if (i == 0) {
		#pragma omp task                  \
			depend(in:square[i][j-1])   \
			depend(inout:square[i][j])
		{
                 sequential(i, j);
		}
          } else if (j == 0) {
		#pragma omp task                  \
			depend(in:square[i-1][j])   \
			depend(inout:square[i][j])
		{
                 sequential(i, j);
		}
	} else {
		#pragma omp task                  \
			depend(in:square[i-1][j])   \
			depend(in:square[i][j-1])   \
			depend(in:square[i-1][j-1]) \
			depend(inout:square[i][j])
		{
                 sequential(i, j);
		}
            }
        }
    }
 //   }
#ifdef GOMP_TRACES
    GOMP_print_task_counters();
#endif

    return square[N - 1][N - 1][BS - 1][BS - 1];
}

int
main(void)
{
	int r;
	
	struct timeval tim;
	
	init_matrix();

	gettimeofday(&tim, NULL);  
	long t1=(tim.tv_sec*1000000) + (tim.tv_usec);  

	r = wavefront();

	gettimeofday(&tim, NULL);  
	long t2=(tim.tv_sec*1000000) + (tim.tv_usec);  

	//printf("\n DIM    N  #tasks   usecs  Result\n");
	printf(" %4d  %2d  %6d  %6ld  %lu \n", DIM, N, N*N, t2-t1, square[N - 1][N - 1][BS - 1][BS - 1]);
	return r;
}


