% Create data
labels = {'Dead','Incoherent Firstprivate','Race','Atuomatic as shared','Incoherent pointer','Incoherent private','Incoherent input', []};
occurrences = [265 175 155 65 60 11 9 ];

% Create a vertical bar chart using the bar function
hold on
for i = 1:length(occurrences)
    h=bar(i, occurrences(i));
    if i == 1
        set(h,'FaceColor',[0.7 0 0.2]);     % red
    elseif i == 2
        set(h,'FaceColor',[0 0.7 0.1]);     % green
    elseif i == 3
        set(h,'FaceColor',[0 0.2 0.8]);     % blue
    elseif i == 4
        set(h,'FaceColor',[0.9 0.4 0.1]);   % orange
    elseif i == 5
        set(h,'FaceColor',[1 0.9 0.1]);     % yellow
    elseif i == 6
        set(h,'FaceColor',[1 0 0.7]);       % magenta
    elseif i == 7
        set(h,'FaceColor',[0.7 0.9 1]);     % light blue
    end
end
hold off
set(gca, 'XTick',1:1:length(labels)+1,'XTickLabel',labels)
%bar(errors, occurrences)


% Set the axis limits
%set(gca, 'XTick', 1:1)

% Add title and axis labels
% title('Childhood diseases by month')
xlabel('Error')
ylabel('Occurrences')

% Add a legend
%legend('Measles', 'Mumps', 'Chicken pox')

h = figure(1);
set(h, 'Position', [100 100  1400 500])

% Make changing paper type possible
set(gcf,'PaperType','<custom>');

% Set units to all be the same
set(gcf,'PaperUnits','inches');
set(gcf,'Units','inches');

% Set the page size and position to match the figure's dimensions
paperPosition = get(gcf,'PaperPosition');
position = get(gcf,'Position');
set(gcf,'PaperPosition',[0,0,position(3:4)]);
set(gcf,'PaperSize',position(3:4));

% Save the pdf (this is the same method used by "saveas")
print(gcf,'-dpdf','eval.pdf',sprintf('-r%d',150))
