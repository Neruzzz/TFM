#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <omp.h>

double CalcPi(int n);

int main()
{
    int n = 15000000;
    const double fPi25DT = 3.141592653589793238462643;
    double fPi;
    double fTimeStart, fTimeEnd;

    if (n <= 0 || n > 2147483647 ) 
    {
        printf("\ngiven value has to be between 0 and 2147483647\n");
        return 1;
    }

    fTimeStart = omp_get_wtime();
    /* the calculation is done here*/
    fPi = CalcPi(n);
    fTimeEnd = omp_get_wtime();

    printf("\npi is approximately = %.20f \nError               = %.20f\n",
           fPi, fabs(fPi - fPi25DT));
    printf("  wall clock time     : %.20f seconds\n", fTimeEnd - fTimeStart);

    return 0;
}


double f(double a)
{
    return (4.0 / (1.0 + a*a));
}


double CalcPi(int n)
{
    const double fH   = 1.0 / (double) n;
    double fSum = 0.0;
    double fX;
    int i;

    #pragma omp parallel 
    #pragma omp single private(i) nowait
    for (i = 0; i < n; i += 1)
    {
    #pragma omp task private(fX) firstprivate(i)
    {
            fX = f(fH * ((double)i + 0.5));
        #pragma omp critical
            fSum += fX;
    }
    }

    return fH * fSum;
}