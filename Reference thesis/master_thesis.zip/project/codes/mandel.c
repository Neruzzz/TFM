#include <stdlib.h>
#include <stdio.h>
#include <omp.h>


struct {
    int nrows,ncols;
    double x0,y0;
    double dx,dy;
} args;


#define MANDEL_MAX_ITER 150
#define MANDEL_DIVERGENCE 2.0

int mandel_point ( double xi, double yi )
{
    double x,y;
    double xs,ys; /** x & y squares */
    int iter;

    iter = 0;
    x = y = 0.0;
    xs = ys = 0.0;
    
    do {
        y = (2.0 * x * y) + xi;
        x = (xs - ys) + yi;
        iter++;
        ys = y * y;
        xs = x * x;
    } while ((iter < MANDEL_MAX_ITER) && ((ys + xs) < MANDEL_DIVERGENCE));

    return iter;
}

void mandel ( int * matrix )
{
    int r,c;
    double deltax,deltay;
    double x,y;

    /**
     * Calculates the increment each position of the matrix represents in real world
     */

    deltax = args.dx/(args.ncols);
    deltay = args.dy/(args.nrows);

    x = args.x0;

    /*
     * In the parallel version move the update of the indexes to absolute formula
     * to avoid contention in the update
     */
    #pragma omp parallel
    {
        int mandel_work = 0;
        #pragma omp for private(x,y,c) schedule(auto) nowait
        for ( r = 0; r < args.nrows; r++ ) {
            x = args.x0 + r*deltax; 
                y = args.y0;
            for ( c = 0; c < args.ncols; c++ ){
                int m = mandel_point(x,y);
                mandel_work += m;
                matrix[r*args.ncols+c] = m;
                y += deltay;
            }
        }
        printf("Thread %d work = %d\n",omp_get_thread_num(),mandel_work);
    }
}



void output_matrix ( int * matrix )
{
    int r,c;

    for ( r = 0; r < args.nrows; r++ ) {
        for ( c = 0; c < args.ncols; c++ )
            printf("%d ",matrix[r*args.ncols+c]);
        printf("\n");
    }
}

int main (int argc, char **argv)
{
    int *matrix;
    double start,end;
    
    if ( argc != 7 ) {
        //printf("Use: %s nrows ncols x0 y0 dx dy\n",argv[0]);
        args.nrows = 2000;
        args.ncols = 2000;
        args.x0 = 0;
        args.y0 = 0;
        args.dx = 1;
        args.dy = 1;
    } else {
        args.nrows = atoi(argv[1]);
        args.ncols = atoi(argv[2]);
        args.x0 = atof(argv[3]);
        args.y0 = atof(argv[4]);
        args.dx = atof(argv[5]);
        args.dy = atof(argv[6]);
    }

    if ( args.nrows <= 0 || args.ncols <= 0 ) {
        printf("Illegal matrix size\n");
        exit(-1);
    }
    
    if ( args.dx <= 0 || args.dy <= 0 ) {
        printf("Illegal region size\n");
        exit(-1);
    }

    matrix = (int *)malloc(args.nrows * args.ncols * sizeof(int));
    start = omp_get_wtime();
    mandel(matrix);
    end = omp_get_wtime();
    printf("Mandelbrot time: %f seconds\n",end-start);
    //output_matrix(matrix);
}
